import numpy as np
# df_raw = np.load('data.npy', allow_pickle=True)
df_raw = np.load('E:/文献/时序生成/DIFFUSION-TS(Time series generation)/Diffusion-TS/Data/Human/human/Eating_all.npy', allow_pickle=True)
print(df_raw.shape)
print[df_raw]

